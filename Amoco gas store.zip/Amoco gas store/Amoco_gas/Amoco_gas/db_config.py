import MySQLdb as dbc

host = "localhost"
paswd = "xbyte"
user = "root"
db_name= "Bp_stores"
table1 = "BP_Stores_data"
# table2 = "OTT_ZEE5_Movies_Data"
