import json
import MySQLdb
import pymongo
import scrapy

from Amoco_gas.items import AmocoGasItem


class BpCrawlSpider(scrapy.Spider):
    name = 'bp_crawl'
    host = 'localhost'
    port = '27017'
    db = 'bp_crawl'

    def start_requests(self):
        try:
            self.connection = MySQLdb.connect('localhost', 'root', 'xbyte', 'bp_stores', charset='utf8')
            self.cursor = self.connection.cursor()
            self.cursor.execute("set names utf8;")
            self.sql = (f"Select * from usa_zip where status = 'pending'")
            self.cursor.execute(self.sql)
            results = self.cursor.fetchall()
            for row in results:

                zip_code = str(row[1]).strip()
                lat = str(row[2]).strip()
                long =str (row[3]).strip()
                main_link = f'https://bpretaillocator.geoapp.me/api/v1/locations/nearest_to?lat={lat}&lng={long}&autoload=true&travel_mode=driving&avoid_tolls=false&avoid_highways=false&show_stations_on_route=true&corridor_radius=5&key=AIzaSyDHlZ-hOBSpgyk53kaLADU18wq00TLWyEc&format=json'
                headers = {
                    'accept': 'application/json, text/javascript',
                    'accept-encoding': 'gzip, deflate, br',
                    'accept-language': 'en-US,en;q=0.9',
                    'content-type': 'application/x-www-form-urlencoded',
                    'if-none-match': 'W/"fb8f366872fc2d71021d8f8e2a613e5a"',
                    'referer': 'https://bpretaillocator.geoapp.me/?locale=en_US',
                    'sec-ch-ua': '"Not;A Brand";v="99", "Google Chrome";v="91", "Chromium";v="91"',
                    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36',
                    'x-requested-with': 'XMLHttpRequest'
                }
                yield scrapy.Request(url=main_link, dont_filter=True, headers=headers,callback=self.get_data1,meta={ "link": main_link, "zip_code": zip_code})

        except Exception as e:
            print(e)

    def get_data1(self,response):
        zip_code = response.meta['zip_code']
        con = pymongo.MongoClient(f'mongodb://{self.host}:{self.port}/')
        mydb = con[self.db]
        conn = mydb['bp_store_data']
        try:
            body = json.loads(response.text)
            l2 = len(body)
            if l2 == 0:
                self.cursor = self.connection.cursor()
                self.cursor.execute("set names utf8;")
                sql = (f"UPDATE Bp_stores.usa_zip SET STATUS = 'No data' WHERE zipcode ='{zip_code}'")
                self.cursor.execute(sql)
                self.connection.commit()
                print('------------------------------- No Data -----------------------------')
                try:
                    key = zip_code
                    html_file_name = (key).replace(' ', '_')
                    HTML_Save_Path = "G:\\store_locatote_page_save\\" + str(html_file_name) + "" + '.html'
                    HTML_Save_Path = HTML_Save_Path.replace('\\', '\\\\')
                    f = open(HTML_Save_Path, 'w', encoding="utf-8")
                    f.write(response.text)
                    f.close()
                except Exception as e:
                    print(e)

            else:
                try:
                    key = zip_code
                    html_file_name = (key).replace(' ', '_')
                    HTML_Save_Path = "G:\\store_locatote_page_save\\" + str(html_file_name) + "" + '.html'
                    HTML_Save_Path = HTML_Save_Path.replace('\\', '\\\\')
                    f = open(HTML_Save_Path, 'w', encoding="utf-8")
                    f.write(response.text)
                    f.close()
                except Exception as e:
                    print(e)

                for i in range(0,l2):
                    try:
                      store_id = body[i]['id']
                    except Exception as e:
                        store_id= ''
                        print(e)
                    try:
                        store_name = body[i]['name']
                    except Exception as e:
                        store_name = ''
                        print(e)
                    try:
                        latitude =body[i]['lat']
                    except Exception as e:
                        latitude = ''
                        print(e)

                    try:
                        longitude =body[i]['lng']
                    except Exception as e:
                        longitude = ''
                        print(e)
                    try:
                        Address = body[i]['address']
                    except Exception as e:
                        Address = ''
                        print(e)

                    try:
                        city = body[i]['city']
                    except Exception as e:
                        city =''
                        print(e)

                    try:
                        state = body[i]['state']
                    except Exception as e:
                        state = ''
                        print(e)

                    try:
                        Zip_code = body[i]['postcode']
                    except Exception as e:
                        Zip_code = ''
                        print(e)
                    try:
                        country_code= body[i]['country_code']
                    except Exception as e:
                        country_code = ''
                        print(e)
                    try:
                        phone_number = body[i]['telephone']
                    except Exception as e:
                        phone_number = ''
                        print(e)
                    try:
                        services = '|'.join(body[i]['facilities']).strip()
                    except Exception as e:
                        services = ''
                        print(e)
                    try:

                        Final_hr = []

                        # ff = body[i]['opening_hours']
                        # final_hr = []
                        try:
                            print(i)


                            len_opening_hours = body[i]['opening_hours']


                            days =body[i]['opening_hours'][0]['days']
                            days_le = len(days)

                            hours =body[i]['opening_hours'][0]['hours']
                            hr_le = len(hours)
                        except Exception as e:
                            days,hours = '',''
                            print(e,"error in days value")

                        if hours != '':
                            Final_hr.append('-'.join(days)+":"+''.join(hours[0]))
                            store_hr = '|'.join(Final_hr)
                        else:
                            print('error in hr',zip_code)
                            store_hr = ''
                    except Exception as e:
                        store_hr = ''
                        print(e)




                    item = AmocoGasItem()
                    item['store_id']= store_id
                    item['store_name']= store_name
                    item['latitude']= latitude
                    item['longitude']= longitude
                    item['Address']= Address
                    item['city']= city
                    item['state']= state
                    item['Zip_code']= Zip_code
                    item['country_code']= country_code
                    item['phone_number']= phone_number
                    item['services']= services
                    item['store_hr']= store_hr
                    # item['HTML_PAGE_SAVE']= HTML_Save_Path
                    conn.insert(dict(item))
                self.cursor = self.connection.cursor()
                self.cursor.execute("set names utf8;")
                sql = (f"UPDATE Bp_stores.usa_zip SET STATUS = 'Done' WHERE zipcode ='{zip_code}'")
                self.cursor.execute(sql)
                self.connection.commit()
                print('------------------------------- Status Updated -----------------------------')
        except Exception as e:
            print(e)



from scrapy.cmdline import execute
# execute("scrapy crawl bp_crawl".split())





