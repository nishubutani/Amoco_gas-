import hashlib
import json

import MySQLdb
import pymongo
import scrapy

from Amoco_gas.items import AmocoGasItem, fuelcommanderItem

#------------------------- mongo datas -------------#

con = pymongo.MongoClient('mongodb://192.168.1.200:27017/')
db = con.amoco_gas
link_t = db.all_zip_code

#------------------------------------------------#

class Data1Spider(scrapy.Spider):
    name = 'fuelcommander'
    allowed_domains = ['example.com']
    start_urls = ['http://example.com/']

    def start_requests(self):
        link = 'https://storerocket.io/api/user/lVyJzNEJ6M/locations?radius=250&units=miles'
        yield scrapy.Request(url=link, dont_filter=True,callback=self.parse)

    def parse(self, response):
        print("hi")
        try:
            try:
                AB = "E:\\store_locatote_page_save\\fuelcommander\\"
                page_save = f'{AB}{"single"}.html'
                print(page_save)
                f = open(AB + str("single") + '.html', 'wb')
                # print(f)
                f.write(response.text.encode('utf-8'))
                f.close()
                print("page save")
            except Exception as e:
                print(e)

            body= json.loads(response.text)

            l = body['results']['locations']
            l = len(l)

            for i in range(0, l):
                try:
                    store_id = body['results']['locations'][i]['id']
                except Exception as e:
                    store_id = ''
                    print(e)
                try:
                    store_name = body['results']['locations'][i]['name']
                except Exception as e:
                    store_name = ''
                    print(e)
                try:
                    latitude = body['results']['locations'][i]['lat']
                except Exception as e:
                    latitude = ''
                    print(e)

                try:
                    longitude = body['results']['locations'][i]['lng']
                except Exception as e:
                    longitude = ''
                    print(e)

                try:
                    Address = body['results']['locations'][i]['address']
                except Exception as e:
                    Address = ''
                    print(e)

                try:
                    Address_line1 = body['results']['locations'][i]['address_line_1']
                except Exception as e:
                    Address_line1 = ''
                    print(e)


                try:
                    city = body['results']['locations'][i]['city']
                except Exception as e:
                    city = ''
                    print(e)

                try:
                    state = body['results']['locations'][i]['state']
                except Exception as e:
                    state = ''
                    print(e)

                try:
                    Zip_code = body['results']['locations'][i]['postcode']
                except Exception as e:
                    Zip_code = ''
                    print(e)
                try:
                    country_code = body['results']['locations'][i]['country']
                except Exception as e:
                    country_code = ''
                    print(e)

                try:
                    phone_number = body['results']['locations'][i]['phone']
                except Exception as e:
                    phone_number = ''
                    print(e)

                try:
                    location_type_name = body['results']['locations'][i]['phone']
                except Exception as e:
                    location_type_name = ''
                    print(e)


                try:
                    allhourlist = []
                    all_Days = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun']
                    for all_Day in all_Days:
                        day_open = body['results']['locations'][i][f'{all_Day}'].strip()
                        temp = all_Day + ": " + day_open
                        allhourlist.append(temp)

                    Store_Hours = '|'.join(allhourlist)
                    print(Store_Hours)
                except Exception as e:
                    Store_Hours = ''
                    print(e, "problm in Store_hours", response.url)



                item = fuelcommanderItem()
                item['store_id'] = store_id
                item['store_name'] = store_name
                item['latitude'] = latitude
                item['longitude'] = longitude
                item['Address'] = Address
                item['Address_line1'] = Address_line1
                item['city'] = city
                item['state'] = state
                item['Zip_code'] = Zip_code
                item['country_code'] = country_code
                item['phone_number'] = phone_number
                item['location_type_name'] = location_type_name
                item['store_hr'] = Store_Hours
                item['HTML_PAGE_SAVE']= page_save

                store_hash_id = bytes(
                    f"{item.get('store_name', '')} {item.get('address', '')} {item.get('store_id', '')}"
                    f" {item.get('city', '')} {item.get('state', '')} {item.get('services', '')}"
                    f"{item.get('Zip_code', '')} {item.get('latitude', '')} {item.get('longitude', '')}"
                    f" {item.get('process_date', '')} ", encoding='utf-8')

                store_hash_id = int(hashlib.md5(store_hash_id).hexdigest(), 16) % (10 ** 16)

                item['Id_Id'] = store_hash_id
                yield item

        except Exception as e:
            print(e)


if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute("scrapy crawl fuelcommander".split())
