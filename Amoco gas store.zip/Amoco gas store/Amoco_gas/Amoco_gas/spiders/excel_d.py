# import pymongo
# import pandas as pd
# import numpy as np
# import xlsxwriter
#
#
#
# # conn = pymongo.MongoClient('mongodb://nishant.b:Nishant#123@51.161.13.140:27017/?authSource=admin')
# conn = pymongo.MongoClient("mongodb://192.168.1.200:27017/")
# db = conn['fuelcommander']
# collection = db['data_extraction_30-06-2021']
# cursor = collection.find({})
#
#
# df = pd.DataFrame(cursor)
# df.pop('_id')
# # df.pop('page_no')
# df.index = np.arange(1, len(df) + 1)
# df.index.name = 'Id'
# # df.to_csv(csv_path+file_from)
# writer = pd.ExcelWriter(f'fuelcommander_store_fulldata.xlsx', engine='xlsxwriter', options={'strings_to_urls': False})
# df.to_excel(writer, index=False)
# writer.close()
# print("Excel Genrated")
