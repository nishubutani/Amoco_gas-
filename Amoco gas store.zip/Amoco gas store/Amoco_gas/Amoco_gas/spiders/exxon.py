import hashlib

import pymongo
import scrapy
from scrapy.cmdline import execute
import json
from scrapy.http import HtmlResponse

from Amoco_gas.items import fuelcommanderItem
from math import asin, cos
from numpy.core._multiarray_umath import rad2deg, deg2rad

#------------------------- mongo datas -------------#

con = pymongo.MongoClient('mongodb://192.168.1.200:27017/')
db = con.amoco_gas

link_t = db.exxon_all_zip_code

#------------------------------------------------#

class ExxonSpider(scrapy.Spider):
    name = 'exxon'
    allowed_domains = []

    def start_requests(self):



        query = link_t.find({'status': 'done'})
        urls = list(query)
        print(len(urls))
        for link in urls:

            lat = link['lat']
            lat = float(lat)
            lon = link['long']
            lon = float(lon)
            zip_code = link['zipcode']


            R = 4000
            rad = 15
            # lat = 14.54408
            # lon = 120.99139

            maxLat = lat + rad2deg(rad / R)
            # print(maxLat)
            minLat = lat - rad2deg(rad / R)
            # print(minLat)

            maxLon = lon + rad2deg(asin(rad / R) / cos(deg2rad(lat)))
            # print(maxLon)
            minLon = lon - rad2deg(asin(rad / R) / cos(deg2rad(lat)))
            # print(minLon)

            headers = {
                'accept': "application/json, text/plain, */*",
                'accept-encoding': "gzip, deflate, br",
                'accept-language': "en-US,en;q=0.9",
                'adrum': "isAjax:true",
                'user-agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
            }


            url = f"https://www.exxon.com/en/api/locator/Locations?Latitude1={maxLat}&Latitude{minLat}&Longitude1={maxLon}&Longitude2={minLon}&DataSource=RetailGasStations&Country=US&Customsort=False"
            print(url)
            yield scrapy.Request(url=url, callback=self.data, dont_filter=True,meta={'zipcode':zip_code},headers=headers)



    def data(self, response):
        zipcode = response.meta['zipcode']
        try:

            AB = "E:\\store_locatote_page_save\\exxon\\"
            page_save = f'{AB}{zipcode}.html'
            print(page_save)
            f = open(AB + str(zipcode) + '.html', 'wb')
            # print(f)
            f.write(response.text.encode('utf-8'))
            f.close()
            print("page save")

        except Exception as e:
            print(e)
            page_save = ''

        jdata = json.loads(response.text)
        for dt in range(0, len(jdata)):
            try:
                station_name = jdata[dt]['DisplayName']
                # print(station_name)
            except Exception as e:
                print(e, "error in data station name")
                station_name = ""
            try:
                locatin_id = jdata[dt]['LocationID']
                # print(locatin_id)
            except Exception as e:
                print(e, "error in data location id")
                locatin_id = ""
            try:
                lat = jdata[dt]['Latitude']
                # print(lat)
            except Exception as e:
                print(e, "error in data latitude")
                lat = ""
            try:
                lng = jdata[dt]['Longitude']
                # print(lng)
            except Exception as e:
                print(e, "error in data longitude")
                lng = ""
            try:
                address = jdata[dt]['AddressLine1']
                # print(address)
            except Exception as e:
                print(e, "error in data Addressline 1")
                address = ""
            try:
                address_2 = jdata[dt]['AddressLine2']
                # print(address_2)
            except Exception as e:
                print(e, "error in data addressline 2")
                address_2 = ""
            try:
                city = jdata[dt]['City']
                # print(city)
            except Exception as e:
                print(e, "error in data city")
                city = ""
            try:
                state = jdata[dt]['StateProvince']
                # print(state)
            except Exception as e:
                print(e, "error in data state")
                state = ""
            try:
                postal_code = jdata[dt]['PostalCode']
                # print(postal_code)
            except Exception as e:
                print(e, "error in data postal code")
                postal_code = ""
            try:
                phone = jdata[dt]['Telephone']
                # print(phone)
            except Exception as e:
                print(e, "error in data phone")
                phone = ""
            try:
                country = jdata[dt]['Country']
                # print(country)
            except Exception as e:
                print(e, "error in data country")
                country = ""
            try:
                hour_lis = jdata[dt]['WeeklyOperatingHours']
                hour_lis_res = HtmlResponse(url="example.com", body=hour_lis, encoding="utf-8")
                hours = "|".join(hour_lis_res.xpath('//li//text()').extract()).replace(' ', ":")
                if hours:
                    pass
                else:
                    hours = jdata[dt]['WeeklyOperatingHours']
                # print(hours)
            except Exception as e:
                print(e, "error in data hours")
                hours = ""

            try:
                jfeatures = jdata[dt]['FeaturedItems']
                features = []
                for j in range(0, len(jfeatures)):
                    titles = jfeatures[j]['Title']
                    features.append(titles)
                features = '|'.join(features)
                # print(features)
            except Exception as e:
                print(e, "error in data features")
                features = ""

            try:
                source_url = (f'https://www.exxon.com/en/find-station/{city}-{state}-{str(station_name).replace(""".""",""" """)}-{locatin_id}').replace(',','').replace('(','').replace(')','').replace("#",'').replace(' ','').replace("'",'').lower()
                # print(source_url)
            except Exception as e:
                print(e,"error in data source url")
                source_url = ""

            try:
                item = fuelcommanderItem()
                item['URL'] = source_url
                item['Station_name'] = station_name
                item['Station_id'] = locatin_id
                item['Latitude'] = lat
                item['Longitude'] = lng
                item['AddressLine1'] = address
                item['AddressLine2'] = address_2
                item['City'] = city
                item['StateProvince'] = state
                item['PostalCode'] = postal_code
                item['Telephone'] = phone
                item['Country'] = country
                item['Hours'] = hours
                item['Features'] = features
                item['page_save'] = page_save
                store_hash_id = bytes(
                    f"{item.get('Station_name', '')} {item.get('Station_id', '')} {item.get('AddressLine1', '')}"
                    f" {item.get('PostalCode', '')} {item.get('City', '')} {item.get('Features', '')}"
                    f"{item.get('Telephone', '')} {item.get('Latitude', '')} {item.get('Longitude', '')}", encoding='utf-8')

                store_hash_id = int(hashlib.md5(store_hash_id).hexdigest(), 16) % (10 ** 16)

                item['Id_Id'] = store_hash_id

                yield item

            except Exception as e:
                print(e, "error in data insertion")

        try:
            link_t.update({'zipcode': zipcode}, {"$set": {"status": 'pending'}})
            print("link updated")
        except Exception as e:
            print(e, "error in done pending")







if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute("scrapy crawl exxon".split())
