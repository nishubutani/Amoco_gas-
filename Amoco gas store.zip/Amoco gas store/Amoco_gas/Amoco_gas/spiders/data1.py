import hashlib
import json

import MySQLdb
import pymongo
import scrapy

from Amoco_gas.items import AmocoGasItem

#------------------------- mongo datas -------------#

con = pymongo.MongoClient('mongodb://192.168.1.200:27017/')
db = con.amoco_gas
link_t = db.all_zip_code

#------------------------------------------------#

class Data1Spider(scrapy.Spider):
    name = 'data1'
    allowed_domains = ['example.com']
    start_urls = ['http://example.com/']

    def start_requests(self):
        try:
            query = link_t.find({'status': 'pending'})
            urls = list(query)
            print(len(urls))
            for link in urls:

                zip_code = link['zipcode']
                lat = link['lat']
                long =link['long']

                # main_link = f'https://bpretaillocator.geoapp.me/api/v1/locations/nearest_to?lat={lat}&lng={long}&autoload=true&travel_mode=driving&avoid_tolls=false&avoid_highways=false&show_stations_on_route=true&corridor_radius=5&key=AIzaSyDHlZ-hOBSpgyk53kaLADU18wq00TLWyEc&format=json'

                main_link = f'https://bpretaillocator.geoapp.me/api/v1/locations/nearest_to?lat={lat}&lng={long}&with_any%5Bsite_brand%5D%5B%5D=AM&autoload=true&travel_mode=driving&avoid_tolls=false&avoid_highways=false&show_stations_on_route=true&corridor_radius=5&key=AIzaSyDHlZ-hOBSpgyk53kaLADU18wq00TLWyEc&format=json'
                headers = {
                    'accept': 'application/json, text/javascript',
                    'accept-encoding': 'gzip, deflate, br',
                    'accept-language': 'en-US,en;q=0.9',
                    'content-type': 'application/x-www-form-urlencoded',
                    'if-none-match': 'W/"fb8f366872fc2d71021d8f8e2a613e5a"',
                    'referer': 'https://bpretaillocator.geoapp.me/?locale=en_US',
                    'sec-ch-ua': '"Not;A Brand";v="99", "Google Chrome";v="91", "Chromium";v="91"',
                    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36',
                    'x-requested-with': 'XMLHttpRequest'
                }
                yield scrapy.Request(url=main_link, dont_filter=True, headers=headers,callback=self.parse,meta={ "link": main_link, "zip_code": zip_code})

        except Exception as e:
            print(e)

    def parse(self, response):
        zip_code = response.meta['zip_code']
        try:
            body = json.loads(response.text)
            l2 = len(body)
            try:
                key = zip_code
                html_file_name = (key).replace(' ', '_')

                AB = "E:\\store_locatote_page_save\\"
                page_save = f'{AB}{html_file_name}.html'
                print(page_save)
                f = open(AB + str(html_file_name) + '.html', 'wb')
                # print(f)
                f.write(response.text.encode('utf-8'))
                f.close()
                print("page save")
            except Exception as e:
                print(e)

            if l2 == 0:
                try:
                    link_t.update({'zip_code': zip_code}, {"$set": {"status": 'done'}})
                    print("link updated")
                except Exception as e:
                    print(e, "error in done pending")

            else:

                for i in range(0, l2):
                    try:
                        store_id = body[i]['id']
                    except Exception as e:
                        store_id = ''
                        print(e)
                    try:
                        store_name = body[i]['name']
                    except Exception as e:
                        store_name = ''
                        print(e)
                    try:
                        latitude = body[i]['lat']
                    except Exception as e:
                        latitude = ''
                        print(e)

                    try:
                        longitude = body[i]['lng']
                    except Exception as e:
                        longitude = ''
                        print(e)
                    try:
                        Address = body[i]['address']
                    except Exception as e:
                        Address = ''
                        print(e)

                    try:
                        city = body[i]['city']
                    except Exception as e:
                        city = ''
                        print(e)

                    try:
                        state = body[i]['state']
                    except Exception as e:
                        state = ''
                        print(e)

                    try:
                        Zip_code = body[i]['postcode']
                    except Exception as e:
                        Zip_code = ''
                        print(e)
                    try:
                        country_code = body[i]['country_code']
                    except Exception as e:
                        country_code = ''
                        print(e)
                    try:
                        phone_number = body[i]['telephone']
                    except Exception as e:
                        phone_number = ''
                        print(e)
                    try:
                        services = '|'.join(body[i]['facilities']).strip()
                    except Exception as e:
                        services = ''
                        print(e)
                    try:

                        Final_hr = []
                        try:
                            print(i)

                            len_opening_hours = body[i]['opening_hours']

                            days = body[i]['opening_hours'][0]['days']
                            days_le = len(days)

                            hours = body[i]['opening_hours'][0]['hours']
                            hr_le = len(hours)
                        except Exception as e:
                            days, hours = '', ''
                            print(e,)

                        if hours != '':
                            Final_hr.append('-'.join(days) + ":" + ''.join(hours[0]))
                            store_hr = '|'.join(Final_hr)
                        else:
                            print('error in hr', zip_code)
                            store_hr = ''
                    except Exception as e:
                        store_hr = ''
                        print(e)



                    item = AmocoGasItem()
                    item['store_id'] = store_id
                    item['store_name'] = store_name
                    item['latitude'] = latitude
                    item['longitude'] = longitude
                    item['Address'] = Address
                    item['city'] = city
                    item['state'] = state
                    item['Zip_code'] = Zip_code
                    item['country_code'] = country_code
                    item['phone_number'] = phone_number
                    item['services'] = services
                    item['store_hr'] = store_hr
                    item['HTML_PAGE_SAVE']= page_save

                    store_hash_id = bytes(
                        f"{item.get('store_name', '')} {item.get('address', '')} {item.get('store_id', '')}"
                        f" {item.get('city', '')} {item.get('state', '')} {item.get('services', '')}"
                        f"{item.get('Zip_code', '')} {item.get('latitude', '')} {item.get('longitude', '')}"
                        f" {item.get('process_date', '')} ", encoding='utf-8')

                    store_hash_id = int(hashlib.md5(store_hash_id).hexdigest(), 16) % (10 ** 16)

                    item['Id_Id'] = store_hash_id
                    yield item

                try:
                    link_t.update({'zipcode': zip_code}, {"$set": {"status": 'done'}})
                    print("link updated")
                except Exception as e:
                    print(e, "error in done pending")




        except Exception as e:
            print(e)


if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute("scrapy crawl data1".split())
