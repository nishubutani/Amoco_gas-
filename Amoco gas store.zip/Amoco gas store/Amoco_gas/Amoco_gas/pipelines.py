# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
import pymongo
from itemadapter import ItemAdapter


class AmocoGasPipeline:
    def __init__(self):

        conn = pymongo.MongoClient("mongodb://localhost:27017/")
        # self.db = conn.amoco_gas
        # self.table = f"data_extraction_28-06-2021"


        # self.db = conn.fuelcommander
        # self.table = f"data_extraction_30-06-2021"


        self.db = conn.exxon
        self.table = f"data_extraction_05-07-2021"

        unique = self.db[self.table].create_index("Id_Id", unique=True)
        # print(unique)

    def process_item(self, item, spider):
        try:
            self.db[self.table].insert(dict(item))
        except Exception as e:
            print(e)

        return item




